"""
train.py
--------
Training pipeline for the solar-panel fault detection model.

Pipeline:
    1. Load PV data
    2. Extract wavelet features
    3. Split into train/test
    4. Train the deep learning classifier
    5. Save the trained model

Author: Mohammad Tanzid Ahmed
"""

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from feature_extraction import build_feature_matrix
from model import build_model


def load_data():
    """
    Load PV signals and labels.

    Replace this stub with your actual data-loading logic
    (reading from CSV, images, or measurement files).

    Returns
    -------
    signals : np.ndarray, shape (n_samples, signal_length)
    labels  : np.ndarray, shape (n_samples,)
    """
    # ---- Placeholder synthetic data for demonstration ----
    rng = np.random.default_rng(42)
    healthy = np.sin(np.linspace(0, 8 * np.pi, 256)) + 0.05 * rng.standard_normal((100, 256))
    faulty = np.sin(np.linspace(0, 8 * np.pi, 256)) + 0.4 * rng.standard_normal((100, 256))
    signals = np.vstack([healthy, faulty])
    labels = np.array([0] * 100 + [1] * 100)  # 0 = healthy, 1 = faulty
    return signals, labels


def main():
    print("Loading data...")
    signals, labels = load_data()

    print("Extracting wavelet features...")
    X = build_feature_matrix(signals)
    y = labels

    # Normalize features
    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print("Building and training model...")
    model = build_model(input_dim=X.shape[1], num_classes=len(np.unique(y)))
    model.fit(
        X_train, y_train,
        validation_split=0.2,
        epochs=30,
        batch_size=16,
        verbose=2,
    )

    print("Evaluating on test set...")
    loss, acc = model.evaluate(X_test, y_test, verbose=0)
    print(f"Test accuracy: {acc:.4f}")

    model.save("models/fault_detection_model.keras")
    print("Model saved to models/fault_detection_model.keras")


if __name__ == "__main__":
    main()
