"""
feature_extraction.py
---------------------
Hybrid wavelet-transform-based feature extraction for solar-panel
fault detection.

This module extracts fault-signature features from PV data using a
multi-level discrete wavelet transform (DWT). These features are then
fed into the deep learning classifier (see model.py).

Author: Mohammad Tanzid Ahmed
"""

import numpy as np
import pywt


def wavelet_features(signal, wavelet="db4", level=4):
    """
    Extract statistical features from the wavelet decomposition of a signal.

    Parameters
    ----------
    signal : 1D array-like
        Input PV signal (e.g., current, voltage, or power over time).
    wavelet : str
        Mother wavelet to use (default: Daubechies-4).
    level : int
        Number of decomposition levels.

    Returns
    -------
    features : np.ndarray
        Concatenated statistical features from each wavelet sub-band.
    """
    coeffs = pywt.wavedec(signal, wavelet, level=level)

    features = []
    for c in coeffs:
        c = np.asarray(c)
        features.extend([
            np.mean(c),            # mean
            np.std(c),             # standard deviation
            np.mean(np.abs(c)),    # mean absolute value
            np.sqrt(np.mean(c**2)),  # RMS energy
            np.max(np.abs(c)),     # peak magnitude
        ])

    return np.array(features)


def build_feature_matrix(signals, wavelet="db4", level=4):
    """
    Apply wavelet feature extraction to a batch of signals.

    Parameters
    ----------
    signals : 2D array-like, shape (n_samples, signal_length)
    wavelet : str
    level : int

    Returns
    -------
    X : np.ndarray, shape (n_samples, n_features)
    """
    return np.array([
        wavelet_features(sig, wavelet=wavelet, level=level)
        for sig in signals
    ])


if __name__ == "__main__":
    # Quick demonstration with a synthetic signal
    demo_signal = np.sin(np.linspace(0, 8 * np.pi, 256)) + 0.1 * np.random.randn(256)
    feats = wavelet_features(demo_signal)
    print(f"Extracted {len(feats)} features from demo signal.")
    print(feats)
