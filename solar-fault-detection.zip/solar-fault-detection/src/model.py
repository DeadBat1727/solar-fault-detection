"""
model.py
--------
Deep learning network for solar-panel fault classification.

Takes the wavelet features (from feature_extraction.py) and classifies
each sample as healthy or faulty (and optionally by fault type).

Author: Mohammad Tanzid Ahmed
"""

from tensorflow import keras
from tensorflow.keras import layers


def build_model(input_dim, num_classes):
    """
    Build a fully-connected deep neural network for fault classification.

    Parameters
    ----------
    input_dim : int
        Number of input features (from wavelet extraction).
    num_classes : int
        Number of output classes (e.g., 2 for healthy/faulty,
        or more for multi-fault classification).

    Returns
    -------
    model : keras.Model
    """
    model = keras.Sequential([
        layers.Input(shape=(input_dim,)),
        layers.Dense(128, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(64, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(32, activation="relu"),
        layers.Dense(num_classes, activation="softmax"),
    ])

    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )

    return model


if __name__ == "__main__":
    # Show the architecture summary
    demo = build_model(input_dim=25, num_classes=2)
    demo.summary()
