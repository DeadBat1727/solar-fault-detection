# Results

Add your thesis output here:
- Training/validation accuracy & loss curves
- Confusion matrix
- Fault-classification performance tables
- Any comparison plots vs. baseline methods

Tip: recruiters and professors look here first — clear figures make a strong impression.
