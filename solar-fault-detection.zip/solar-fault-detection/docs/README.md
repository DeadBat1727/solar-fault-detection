# Documentation

Place your full thesis report (PDF), presentation slides, and key figures here.

Suggested files:
- Thesis_Report.pdf
- Presentation_Slides.pdf
- methodology_diagram.png
