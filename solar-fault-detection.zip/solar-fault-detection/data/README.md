# Data

This folder describes the dataset used for solar-panel fault detection.

## Dataset Description

> _Describe your dataset here. For example:_
> - **Source:** (e.g., field-measured PV data, public solar fault dataset, or simulated data)
> - **Size:** number of samples / images
> - **Classes:** e.g., Healthy, Shading, Soiling, Hotspot, Cracked cell
> - **Format:** CSV / images / time-series signals

## Notes

- Large raw datasets are **not** uploaded to GitHub (file-size limits). Keep them in cloud storage (Google Drive) and link here instead.
- A small sample is provided so others can understand the data format.

*(Placeholder — replace with your actual dataset details.)*
