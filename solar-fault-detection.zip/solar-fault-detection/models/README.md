# Models

Trained model files are saved here after running `src/train.py`.

Large model files (.keras, .h5) are excluded from git via .gitignore.
Store them in cloud storage and link here if needed.
